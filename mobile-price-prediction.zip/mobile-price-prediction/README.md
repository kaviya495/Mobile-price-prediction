# 📱 Mobile Phone Price Prediction using Machine Learning

## 📌 Overview
This project predicts the **price range** of smartphones (low to very high) based on hardware features like RAM, battery, and camera using various **machine learning algorithms**.

## 🧠 Objective
To help customers and businesses estimate smartphone pricing by applying classification models to historical data.

## 📂 Dataset
- Source: [Kaggle – Mobile Price Classification](https://www.kaggle.com/datasets/iabhishekofficial/mobile-price-classification)
- Samples: 2000
- Features: 20
- Target: Price range (0–3)

## 🔍 Feature Selection
Selected top 4 features based on correlation:
- RAM
- Battery Power
- Pixel Width
- Pixel Height

## 🔧 Technologies Used
- Python
- Pandas, NumPy, Scikit-learn, Matplotlib
- SVM, Decision Tree, KNN, Naive Bayes

## 📊 Model Evaluation

| Model         | Accuracy | Precision | Recall | F1 Score |
|---------------|----------|-----------|--------|----------|
| **SVM**       | **87%**  | **87%**   | **87%**| **87%**  |
| Decision Tree | 79%      | 79%       | 79%    | 79%      |
| KNN           | 51%      | 54%       | 51%    | 52%      |
| Naive Bayes   | 80%      | 80%       | 80%    | 80%      |

## ✅ Conclusion
- **SVM** showed superior performance after feature selection.
- The model helps customers and sellers make smarter pricing decisions based on phone specs.

## 📈 Future Work
- Test additional feature selection methods.
- Deploy as a web app where users can enter specs and get price prediction.
